<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class product extends CI_Controller {

        public function __construct() 
        {
        parent::__construct();
        //$this->load->model('generic_model');
        //&& $this->uri->segment(1)!="userlogout"
        //  if ($this->session->userdata('dekho_userId') == ''){
        // redirect ('');}
        // else{
         $this->load->model('generic_model');

        //$this->load->model('backend/model_permissions');
        // }
         $this->load->library('form_validation');
        $this->load->model('user_model');
        $this->load->model('load_model');
        $this->user_model->check_login("admin");
        $this->userInfo = $this->user_model->userInfo("first_name,last_name");

        }
        public function index()
        {
        $data['menu'] = $this->load_model->menu();
        $data['base_url'] = base_url();
        $data['userInfo'] = $this->userInfo;      
        $data["producttype"]=$this->generic_model->getAllRecords("producttype",array("is_deleted"=>0)
        ,"id","DESC");

        $data['page']='product/list';
        $this->load->view('Template/main',$data);

        }

        public function add()
        {
            $data['menu'] = $this->load_model->menu();
        $data['base_url'] = base_url();
        $data['userInfo'] = $this->userInfo; 
        $data["page"]='product/add';
        $this->load->view('Template/main',$data);

        }

        public function save()
        {

        if ($_POST )
        {
        $this->form_validation->set_rules('name', 'Name no', 'trim|required');
        $this->form_validation->set_rules('dec', 'Description', 'trim|required');
    if($this->form_validation->run()==False)
  {
      $data['menu'] = $this->load_model->menu();
        $data['base_url'] = base_url();
        $data['userInfo'] = $this->userInfo; 
        $data["page"]='product/add';
        $this->load->view('Template/main',$data);
  }  
  else{  
        $data["name"]=$this->input->post('name');
        $data["description"]=$this->input->post('dec');
        $data["createdAt"]=date("Y-m-d h:i:sa");
        // $data["createdBy"]=$this->session->userdata('dekho_userId');

        $this->db->insert('producttype', $data);
        ;


        $this->session->set_flashdata('msg', "Add producttype, Information has been added successfully");
        redirect('product/add');
    
     }
        }

        else{
        $this->session->set_flashdata('msg', "Add producttype,id reference is missing or incorrect");
        redirect('product/add');
        }

        }
        public function pricehistory()
        {
            $data['menu'] = $this->load_model->menu();
        $data['base_url'] = base_url();
        $data['userInfo'] = $this->userInfo; 
        //$data["product"]=$this->generic_model->getProductPriceHistory();
        
           

$this->db->select('product.heading, product_histroy.price,product_histroy.date');
$this->db->from('product');
$this->db->join('product_histroy','product_histroy.p_id = product.id');
            $this->db->where('product.is_deleted',0);
            $query=$this->db->get();
            $data['product']=$query->result_array();

        $data['page']='product/history';
        $this->load->view('Template/main',$data);
        //}
        }

        public function delete()
        {
            $data['menu'] = $this->load_model->menu();
        $data['base_url'] = base_url();
        $data['userInfo'] = $this->userInfo; 
        $id=$this->uri->segment(3);
        $done=$this->db->where('id',$id)->update('producttype',array('is_deleted'=>1));
        if($done)
        {
        $this->session->set_flashdata('msg', 'Product is Deleted!');
        redirect('product/index');
        }
        else 
        {
        $this->session->set_flashdata('msg',' Error: Product is not Deleted');
        redirect('product/index');
        }

        }   
        public function states()
        {
        
        $id=$this->uri->segment(3);
        $done=$this->db->where('id',$id)->update('producttype',array('status'=>1));
        if($done)
        {
        $this->session->set_flashdata('msg', 'Product is Deleted!');
        redirect('product/index');
        }
        else 
        {
        $this->session->set_flashdata('msg',' Error: Product is not Deleted');
        redirect('product/index');
        }

        }  
        public function active()
        {
        $id=$this->uri->segment(3);
        $done=$this->db->where('id',$id)->update('producttype',array('status'=>0));
        if($done)
        {
        $this->session->set_flashdata('msg', 'Product is Deleted!');
        redirect('product/index');
        }
        else 
        {
        $this->session->set_flashdata('msg',' Error: Product is not Deleted');
        redirect('product/index');
        }

        }    
        public function editt($id)
        {
            $data['menu'] = $this->load_model->menu();
        $data['base_url'] = base_url();
        $data['userInfo'] = $this->userInfo; 
        $id=$this->uri->segment(3);

        $data['product'] = $this->db->select()->from('producttype')->where('id',$id)
        ->get()->row();
        // var_dump( $data['product']);
        // die();
        $data['page']='product/edit';
        $this->load->view('Template/main',$data);
        }

        public function update()
        {
        //$this->load->model('generic_model');
        // $id=decode_uri($this->uri->segment(2));
        $id=$this->input->post('id');
        $data["name"]=$this->input->post('name');
        $data["description"]=$this->input->post('dec');
        $data["modifiedAt"]=date("Y-m-d h:i:sa");
        $this->db->where('id',$id);
        $this->db->update('producttype',$data);
        $this->session->set_flashdata('msg', "producttype record has been updated successfully");
        redirect('product/index');  
        }

//===================== product add update delete all work start====================// 
        public function list_prodcut()
        {
            $data['menu'] = $this->load_model->menu();
        $data['base_url'] = base_url();
        $data['userInfo'] = $this->userInfo; 
        
        
        //$data["product"]=$this->generic_model->getProduct();
            $this->db->select('product.id,product.price,product.heading,product.description,product.status,unit.name as unitname,producttype.name as pname');
            $this->db->from('product');
           
             $this->db->join('producttype','producttype.id=product.product_type');
              $this->db->join('unit','unit.id=product.unit_id');
             // $this->db->order_by("course_name","desc")
             // $this->db->order_by('product_histroy.price','desc');
            $this->db->where('product.is_deleted',0);
            $query=$this->db->get();
            $data['product']=$query->result_array();
            
        $data['page']='product/listproduct';
        $this->load->view('Template/main',$data);
        }

        public function add_product()
        {
            $data['menu'] = $this->load_model->menu();
        $data['base_url'] = base_url();
        $data['userInfo'] = $this->userInfo; 
        $data["productid"]=$this->generic_model->getSpecificRecord("product", array()); 
        $data["unitid"]=$this->generic_model->getSpecificRecord("unit", array()); 
        $data["producttype"]=$this->generic_model->getAllRecords("producttype",array("is_deleted"=>0,"status"=>0),"id","DESC"); 
        $data["unit"]=$this->generic_model->getAllRecords("unit",array("is_deleted"=>0,"status"=>0),"id","DESC"); 
        $data["page"]='product/add_product';
        $this->load->view('Template/main',$data);
        }
        public function save_product()
        {

        if ($_POST )
        {
        $this->form_validation->set_rules('heading', 'Name no', 'trim|required');
        $this->form_validation->set_rules('unit_id', 'Unit select', 'trim|required');
         $this->form_validation->set_rules('product_type', 'product type Select', 'trim|required');
        $this->form_validation->set_rules('description', 'Description', 'trim|required');
         $this->form_validation->set_rules('price', 'price', 'trim|required');
      
    if($this->form_validation->run()==False)
  {
      $data['menu'] = $this->load_model->menu();
        $data['base_url'] = base_url();
        $data['userInfo'] = $this->userInfo; 
     $data["productid"]=$this->generic_model->getSpecificRecord("product", array()); 
        $data["unitid"]=$this->generic_model->getSpecificRecord("unit", array()); 
        $data["producttype"]=$this->generic_model->getAllRecords("producttype",array("is_deleted"=>0,"status"=>0),"id","DESC"); 
        $data["unit"]=$this->generic_model->getAllRecords("unit",array("is_deleted"=>0,"status"=>0),"id","DESC"); 

        $data["page"]='product/add_product';
        $this->load->view('Template/main',$data);
  }  
  else{

        date_default_timezone_set("Asia/Karachi");
        $this->load->model('generic_model');
        $data["heading"]=$this->input->post('heading');
        $data["unit_id"]=$this->input->post('unit_id');
        $data["product_type"]=$this->input->post('product_type');
        $data["description"]=$this->input->post('description');
        $data["price"]=$this->input->post('price');
        $histroy["price"]=$this->input->post('price');
        $data["createdAt"]=date("Y-m-d h:i:sa");
        // $data["createdBy"]=$this->session->userdata('dekho_userId');
        
         $this->db->insert("product",$data);
         $history['p_id'] = $this->db->insert_id();
         $history["price"]=$this->input->post('price');
         $history["date"]=date("Y-m-d h:i:sa");


        
       $this->db->insert("product_histroy",$history);
     
        
        
        $this->session->set_flashdata('msg', "Add product, Information has been added successfully");
        redirect('product/list_prodcut');
        }
    }
        else{
        $this->session->set_flashdata('msg', "Add product,  reference is missing or incorrect");
        redirect('product/list_prodcut');
        }

        }

        public function List_delete()
        {
        $id=$this->uri->segment(3);
        $done=$this->db->where('id',$id)->update('product',array('is_deleted'=>1));
        if($done)
        {
        $this->session->set_flashdata('msg', 'Product is Deleted!');
        redirect('product/list_prodcut');
        }
        else 
        {
        $this->session->set_flashdata('msg',' Error: Product is not Deleted');
        redirect('product/list_prodcut');
        }

        }

        public function List_edit()
        {
            $data['menu'] = $this->load_model->menu();
        $data['base_url'] = base_url();
        $data['userInfo'] = $this->userInfo; 
         $id=$this->uri->segment(3);
      
        $data['product'] = $this->db->select()->from('product')->where('id',$id)
        ->get()->row();
        $data['histroy'] = $this->db->select()->from('product_histroy')->where('p_id',$id)
        ->get()->row();
        
        $data['page']='product/edit_product';
        $this->load->view('Template/main',$data);
        }

        public function update_list_product()
        {
        if($_POST)
        {
        $this->form_validation->set_rules('heading', 'Name no', 'trim|required|alpha');
        $this->form_validation->set_rules('unit_id', 'Unit select', 'trim|required');
         $this->form_validation->set_rules('product_type', 'product type Select', 'trim|required');
        $this->form_validation->set_rules('description', 'Description', 'trim|required');
         $this->form_validation->set_rules('price', 'price', 'trim|required');
      
    if($this->form_validation->run()==False)
  {
  
       $data['menu'] = $this->load_model->menu();
        $data['base_url'] = base_url();
        $data['userInfo'] = $this->userInfo;    
    $id=$this->input->post('id');
     $data['product'] = $this->db->select()->from('product')->where('id',$id)
        ->get()->row();
       // var_dump($data['product']);
        //die();
        $data['page']='Product/edit_product';
        $this->load->view('Template/main',$data);

}
else{


        date_default_timezone_set("Asia/Karachi");
        //    $data["id"]=$id;
        $id=$this->input->post('id');
        $this->load->model('generic_model');
        $data["heading"]=$this->input->post('heading');
        $data["unit_id"]=$this->input->post('unit_id');
        $data["price"]=$this->input->post('price');
        $data["product_type"]=$this->input->post('product_type');
        $data["description"]=$this->input->post('description');
        $histroy["price"]=$this->input->post('price');
        $histroy["p_id"]=$this->input->post('id');
         $histroy["date"]=date("Y-m-d h:i:sa");
        
        
        $data["modifiedAt"]=date("Y-m-d h:i:sa");
         $da=$this->db->select()->from('product_histroy')->where('p_id',$id)->get()->row();
                   
                    if( $histroy["price"]==$da->price)
                    {
                    $this->db->where('id',$id);
                    $this->db->update('product',$data);
                    }
                    else
                    {
                      $this->db->insert("product_histroy",$histroy);
                       $this->db->where('id',$id);
                       $this->db->update('product',$data);
                    }
        //var_dump($data);
        //die();
        // $data["createdBy"]=$this->session->userdata('dekho_userId');
                $this->db->where('id',$id);
        $this->db->update('product',$data);

        $this->session->set_flashdata('msg', "Update product, Information has been added successfully");
        redirect('product/list_prodcut');
        }
    }
        else{
        $this->session->set_flashdata('msg', "Update product,  reference is missing or incorrect");
        redirect('product/list_prodcut');
        }
        }
        
        
        

        //===================== End of  product add update delete all work start====================// 
             public function states_p()
        {
        
        $id=$this->uri->segment(3);
        $done=$this->db->where('id',$id)->update('product',array('status'=>1));
        if($done)
        {
        $this->session->set_flashdata('msg', 'Product is deactive!');
        redirect('product/list_prodcut');
        }
        else 
        {
        $this->session->set_flashdata('msg',' Error: Product is not deactive');
        redirect('product/list_prodcut');
        }

        }  
        public function active_p()
        {
        $id=$this->uri->segment(3);
        $done=$this->db->where('id',$id)->update('product',array('status'=>0));
        if($done)
        {
        $this->session->set_flashdata('msg', 'Product is active!');
        redirect('product/list_prodcut');
        }
        else 
        {
        $this->session->set_flashdata('msg',' Error: Product is not active');
        redirect('product/list_prodcut');
        }

        } 


}