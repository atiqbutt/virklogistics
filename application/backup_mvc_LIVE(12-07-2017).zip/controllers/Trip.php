<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class trip extends CI_Controller {

        public function __construct() 
        {
        parent::__construct();
        $this->load->model('trip_model');
         $this->load->model('generic_model');
         $this->load->library('form_validation');

           $this->load->model('generic_model');

        //$this->load->model('backend/model_permissions');
        // }
         $this->load->library('form_validation');
        $this->load->model('user_model');
        $this->load->model('load_model');
        $this->user_model->check_login("admin");
        $this->userInfo = $this->user_model->userInfo("first_name,last_name");


        }
        public function index()
        {
         $data['menu'] = $this->load_model->menu();
        $data['base_url'] = base_url();
        $data['userInfo'] = $this->userInfo;  
        
        
            $this->db->select('tripmanagement.id,tripmanagement.status,tripmanagement.trip_type,tripmanagement.trip_category,tripmanagement.fuel,vehicle.registerationno');
            $this->db->from('tripmanagement');
            $this->db->join('vehicle','vehicle.id=tripmanagement.vehicle_id');
            $this->db->where('tripmanagement.is_deleted',0);
            $query=$this->db->get();
            $data['tripmanagement']=$query->result_array();
            
           // var_dump($data['tripmanagement']);
            //die();
        
   //$data["tripmanagement"]=$this->generic_model->getAllRecords("tripmanagement",array("is_deleted"=>0)
     //   ,"id","DESC");
        
  // var_dump($data["tripmanagement"]);
   //die();

        $data["page"]='Trip/trip_list';
        $this->load->view('Template/main',$data);

        }
          
           public function delete()
        {
        $id=$this->uri->segment(3);
        $done=$this->db->where('id',$id)->update('tripmanagement',array('is_deleted'=>1));
        if($done)
        {
        $this->session->set_flashdata('msg', 'trip is Deleted!');
        redirect('trip/index');
        }
        else 
        {
        $this->session->set_flashdata('msg',' Error: trip is not Deleted');
        redirect('trip/index');
        }

        }   
        public function states()
        {
        $id=$this->uri->segment(3);
        $done=$this->db->where('id',$id)->update('tripmanagement',array('status'=>1));
        if($done)
        {
        $this->session->set_flashdata('msg', 'trip is Deactive!');
        redirect('trip/index');
        }
        else 
        {
        $this->session->set_flashdata('msg',' Error: trip is not  Deactive');
        redirect('trip/index');
        }

        }  
        public function active()
        {
        $id=$this->uri->segment(3);
        $done=$this->db->where('id',$id)->update('tripmanagement',array('status'=>0));
        if($done)
        {
        $this->session->set_flashdata('msg', 'trip is active!');
        redirect('trip/index');
        }
        else 
        {
        $this->session->set_flashdata('msg',' Error: trip is not active');
        redirect('trip/index');
        }
        }


public function add_trip()
	   {

        $data['menu'] = $this->load_model->menu();
        $data['base_url'] = base_url();
        $data['userInfo'] = $this->userInfo;  
			$data["driverinformation"]=$this->trip_model->getAllRecords("driverinformation",array("is_deleted"=>0,"status"=>0),"id","DESC");	
			$data["helperinformation"]=$this->trip_model->getAllRecords("helperinformation",array("is_deleted"=>0,"status"=>0),"id","DESC");	
			$data["vehicle"]=$this->trip_model->getAllRecords("vehicle",array("is_deleted"=>0,"status"=>0),"id","DESC");	
	        $data["product"]=$this->trip_model->getAllRecords("product",array("is_deleted"=>0,"status"=>0),"id","DESC");	
			$data["contractor"]=$this->trip_model->getAllRecords("contractorinformation",array("is_deleted"=>0,"status"=>0),"id","DESC");	
			$data["customer"]=$this->trip_model->getAllRecords("customerinformation",array("is_deleted"=>0,"status"=>0),"id","DESC");
			$data["routedefination"]=$this->trip_model->getAllRecords("routedefination",array("is_deleted"=>0),"id","DESC");	

	  		$data['page'] = "Trip/add_trip";
			$this->load->view('Template/main', $data);
	   }


	public function save_trip()
	   {
//var_dump($this->input->post());die;
	   		if ($this->input->post()) {
	   			 $data["trip_type"]=$this->input->post('trip_type');
	           $data["trip_category"]=$this->input->post('trip_category');
	           $data["vehicle_id"]=$this->input->post('vehicle_id'); 
	           $driver_id=$this->input->post('driver_id'); 
	           $helper_id=$this->input->post('helper_id'); 

	           $data["fuel"]=$this->input->post('fuel'); 
	           $data["start_meter_reading"]=$this->input->post('start_meter_reading'); 
	           $data["date"]=$this->input->post('date'); 
	           $data["description"]=$this->input->post('description');
	           $data["createdAt"]=date("Y-m-d h:i:sa");
	       		//$data["createdBy"]=$this->session->userdata('dekho_userId');

				$tripid=$this->trip_model->save("tripmanagement",$data);
				
				$data1["tripid"]=$tripid;       
				$data1["product_id"]=$this->input->post('product_id'); 
				$data1["product_quantity"]=$this->input->post('product_quantity'); 
				$data1["product_temperature"]=$this->input->post('product_temperature'); 
				$data1["product_gravity"]=$this->input->post('product_gravity'); 
				$data1["company"]=$this->input->post('company'); 
				$data1["contractor_id"]=$this->input->post('contractor_id'); 
				$data1["createdAt"]=date("Y-m-d h:i:sa");
				//$data1["createdBy"]=$this->session->userdata('dekho_userId');
				$this->trip_model->save("triporders",$data1);
				
				$insert_driver=array();
				foreach ($driver_id as $value) {
				$insert_driver[]=array(
							'trip_id'=>$tripid,
							'type'=>'driver',
							'member_id'=>$value

							);


	           	}
					// echo "<pre>";    
					// var_dump($insert_driver);die();
					// echo "</pre>"; 

	      		$this->db->insert_batch('trip_members', $insert_driver);


	           	$insert_helper=array();
				foreach ($helper_id as $value) {
				$insert_helper[]=array(
								'trip_id'=>$tripid,
								'type'=>'helper',
								'member_id'=>$value

							);
	           	}

	           	$this->db->insert_batch('trip_members', $insert_helper);
		
	            $this->session->set_flashdata('success', "Add tripmanagement, Information has been added successfully");
	            redirect('trip/index');
	   	 
	   		}else{

	   			$this->session->set_flashdata('Errors', "There are some errors !!");
	            redirect('trip/add_trip');
	   		}

	          
	   }




    }
