 <!-- /.row -->
 <section class="content">
      <div class="row">
        <div class="col-xs-12">
         <?php if ($this->session->flashdata('msg' )): ?>
             <div class="alert alert-success">
             <?php echo $this->session->flashdata('msg'); ?>  
          </div>
          <?php endif; ?>


				          <?php if ($this->session->flashdata('success' )): ?>
				          <div class="alert alert-success">
				          <?php echo $this->session->flashdata('success'); ?>  
				          </div>
				          <?php endif; ?>


				          <?php if ($this->session->flashdata('errors' )): ?>
				          <div class="alert alert-danger">
				          <?php echo $this->session->flashdata('errors'); ?>  
				          </div>
				          <?php endif; ?>

          
          <div class="box col-sm-3" style="padding-top:20px">
            <a  class="btn btn-success"  href="<?php echo base_url();?>Trip/add_trip">Add Trip</a>
 
            <div class="box-header" style="padding-top:50px" >
              <h3 class="box-title">List Trip</h3>
            </div>
            
            <!-- /.box-header -->
            <div class="box-body">

              <table id="example2" class="table table-bordered table-hover">
                <thead>
                <tr>
                                    <th>Trip Type</th>  
                                    <th>Trip category</th> 
                                    <th>fuel</th> 
                                     <th>Vechile</th> 
                                    <th>Action</th> 
                                    <th>Status</th>
                                    
                                   
                                    
                                </tr>
                            </thead>
                            <tbody>
                            <?php
                            if(!empty($tripmanagement))
                            {
                            foreach($tripmanagement as $amb){ ?>
                                <tr class="odd gradeX">
                                <td>
                              <?php echo $amb["trip_type"];?> 
                                </td>
                                 <td>
                              <?php echo $amb["trip_category"];?> 
                                </td>
                                <td>
                              <?php echo $amb["fuel"];?> 
                                </td>
                                
                                <td>
                              <?php echo $amb["registerationno"];?> 
                                </td>
                                


                                  
                                
                            
                              
                                    <td>
                                    
                                       


                                          <a class="text-custom1" href="<?php echo base_url();?>trip/edit/<?php echo $amb['id'];?>"><i class="fa fa-edit fa-1x"></i></a> 
               <a class="text-custom1" href="<?php echo base_url();?>trip/delete/<?php echo $amb['id'];?>"><i class="fa fa-trash fa-1x"></i></a>

                               
                                 </td>

                                                  <td>
                                        <?php if ($amb["status"]=="0"){?>
                                                                      
<a class="text-custom1" href="<?php echo base_url();?>trip/states/<?php echo $amb['id'];?>">
  <img src="<?php echo base_url();?>assets/Images/2.png" width="20px" height="20px"></a>
                                              
                                        

                                    <?php } elseif($amb["status"]=="1") {?>
                                                   
                                                    <a class="text-custom1" href="<?php echo base_url();?>trip/active/<?php echo $amb['id'];?>"><img src="<?php echo base_url();?>assets/Images/3.png" width="20px" height="20px"></a>
                                                 
                                                 
                                       
                                    <?php } ?>
                                    
                                </td>





                            </tr>
                            <?php } }?>

                           
                            </tbody>
                        </table>
               </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 