 <section class="content">
      <div class="row">
        <div class="col-xs-12">
         <?php if ($this->session->flashdata('msg' )): ?>
             <div class="alert alert-success">
             <?php echo $this->session->flashdata('msg'); ?>  
          </div>
          <?php endif; ?>
          
               <div style="padding-left:0px;" class="panel-heading">
                 
              </div>
          <div class="box col-sm-3" >
            
            <div class="box-header" style="padding-top:25px" >
              <h2 class="box-title"><b>List Product Type</b></h2>
            </div>
            
            <!-- /.box-header -->
            <div class="box-body">
            
              <table  id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th> Name</th>
                                    
                                       <th> Price</th>
                                        <th>  Date</th>
                                       
                                   
                </tr>
                </thead>
                <tbody>
                <?php
                            foreach($product as $amb){ ?>
                                <tr class="odd gradeX">
                                <td><?php echo $amb["heading"];?></td>
                                  <td><?php echo $amb["price"];?></td>
                                  <td><?php echo $amb["date"];?></td>
                                
                                
                                
                            </tr>
                            <?php } ?>

                </tbody>
               
             
              </table>
                    </div>
                </div>
                <!-- /.panel-body -->
            </div>
            <!-- /.panel -->
        </div>
        <!-- /.col-lg-12 -->
    </div>
            