<style>
    .per-table td {
        padding: 5px 5px;
    }
    
    .sub-submenu {
        margin-left: 50px;
    }
</style> 
 <!-- /.row -->
 <section class="content">
     <form action="<?php echo base_url(); ?>admin/permission/assign" method="post">
      <div class="row">
        <div class="col-xs-12">
          <div class="box col-sm-3">
            <div class="box-header" >
                <h3 class="box-title">Permissions</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
                        <div class="form-group">
                            <label for="role">Role:</label>
                            <select name="role" id="role" class="form-control col-md-12 col-sm-12 col-xs-12">
                                <option value="">Select Role</option>
                                <?php foreach ($roles as $key => $value) {
                                    if(!$is_super)
                                    {
                                        if($value['title']!="Super" AND $value['title']!="Admin")
                                            echo '<option value="'.$value['id'].'">'.$value['title'].'</option>';
                                    }
                                    else
                                        echo '<option value="'.$value['id'].'">' . $value['title']. '</option>';
                                } ?>
                            </select>
                        </div>

                        <div class="row">
                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <div class="checkbox">
                                    <label>
                                        <input type="checkbox" id="all"> All
                                    </label>
                                </div>
                            </div>
                            <button class="btn btn-success pull-right" type="submit">Save</button>
                        </div>
                  <!--</form>-->
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
      <div id="permision_wrapper">
          <?php echo $per_menu; ?>
      </div>
    </form>
    </section>
 
     <script>
        $(document).ready(function(){
            $(document).on("change","#role",function(){
                var value = $(this).val();
                $.get("<?php echo base_url(); ?>admin/per_menu/"+value,{},function(d){
                    $("#permision_wrapper").html(d);
                    $('.box').boxWidget();
                });
            });
            $('#all').click(function() {   
                if ($(this).is(':checked')) {
                    $(".sub_menu").prop( "checked", true );
                } else {
                    $(".sub_menu").prop( "checked", false );
                }
            });
            
        });
    </script>
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 