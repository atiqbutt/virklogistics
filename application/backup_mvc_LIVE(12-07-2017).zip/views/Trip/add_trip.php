<section class="content">
            <div class="box">

                <div class="box-header">
                  <h3 class="box-title">Add Trip</h3>
                </div>

                <div class="box-body">

            <form id="myform" action="<?php echo base_url() ?>Trip/save_trip" method="post" enctype="multipart/form-data">

          <div class="row">
            <div class="col-lg-6">
                <div class="panel panel-default">
                  <div class="panel-heading">Trip Information</div>
                  <div class="panel-body">
                    <div class="form-group">
                    <label>Trip Type:</label>
                    <select class="form-control" name="trip_type" required> 
                        <option value="">Select Options</option>       
                        <option value="Self">Self</option>                                                              
                        <option value="General">General</option>
                    </select>
                    </div>
                     <div class="form-group">
                    <label>Trip Category:</label>

                    <select class="form-control" name="trip_category" required>
                       <option value="">Select Options</option>       
                        <option value="Long">Long</option>                                                              
                        <option value="Short">Short</option>                                                  
                    </select>
                  </div>
                
                  <div class="form-group">
                  <label>Date & Time:</label>
                  <input class="form-control" type="date" name="date" value="" required>
                   </div>   

                  <div class="form-group">    
                  <label>Remarks:</label>
                  <input class="form-control" value="<?php if(isset($result)){echo $result['description'];}  ?>" type="text" name="description"  required="required" />
                  </div>  

                  </div>
                  <!-- panel-body -->
                </div>
                <!-- panel panel-default -->
            </div>
              <!-- col-lg-6 -->

          <div class="col-lg-6">

              <div class="panel panel-default">
                  <div class="panel-heading">Tanker Info</div>
                  <div class="panel-body">
                                 <div class="form-group">    
                                <label>Vehicle:</label>
                                  <select class="form-control" name="vehicle_id" required>
                               <option value="">Select Options</option>       

                                <?php if(!empty($vehicle)){
                          foreach ($vehicle as $v){  ?>      
                                    <option value="<?php  echo  $v["id"];?>"   >
                                      <?php  echo  $v["registerationno"];?>
                                      </option>               
                                      <?php }} ?>
                                  </select> 
                                    </div>
                               <div class="form-group">    
                                <label>Fuel:</label>
                                  <input class="form-control" value="" type="text" name="fuel"  required="required" />
                                   </div>
                      
                              <div class="form-group"> 
                                <label>Start Meter Reading:</label>
                                  <input class="form-control" value="" type="text" onkeypress="return ValidateNumberOnly()" name="start_meter_reading"  required="required" />
                                </div>  
                              
                              <div class="form-group"> 
                                <label>Route:</label>
                                  <select class="form-control" name="product_type" selected="selected">
                                <option value="">Select Options</option>       
          
                                <?php if(!empty($routedefination)){
                        foreach ($routedefination as $rd){ ?>                   
                                    <option value="<?php  echo  $rd["id"];?>"   >
                                     
                                    <?php  echo$rd["source"];echo "-"; echo $rd["destination"];?>
                                     </option>               
                                      <?php }} ?>
                                  </select> 
                                   </div>  

                  </div>
                  <!-- panel-body -->
                </div>
                <!-- panel panel-default -->
              </div>
              <!-- col-lg-6 -->
            </div>
            <!-- row -->


            <div class="row">
    

              <div class="col-lg-6">
                <div class="panel panel-default">
                  <div class="panel-heading">All Fields Are Required </div>
                  <div class="panel-body">
                                 <div class="form-group"> 
                                    <label>Product :</label>
                                      <select class="form-control" name="product_id" selected="selected" required> 
                                      <option value="">Select Options</option>       
          
                                  <?php  if(!empty($product)){
                          foreach ($product as $p){   ?>      
                                          <option value="<?php  echo  $p["id"];?>"   >
                                        <?php  echo  $p["heading"];?>
                                          </option>               
                                          <?php }} ?>
                                      </select> 
                                   </div>

                                 <div class="form-group"> 
                                    <label>Product Quantity:</label>
                                      <input class="form-control" value="<?php if(isset($result)){echo $result['description'];}  ?>" type="text" name="product_quantity" onkeypress='return ValidateNumberOnly()' required="required" />
                                      </div>

                                    <div class="form-group"> 
                                    <label>Product Temperature:</label>
                                      <input class="form-control" value="<?php if(isset($result)){echo $result['description'];}  ?>" type="text" name="product_temperature"   required="required" />
                                    </div>

                                    <div class="form-group"> 
                                    <label>Product Gravity:</label>
                                      <input class="form-control" value="<?php if(isset($result)){echo $result['description'];}  ?>" type="text" name="product_gravity"  required="required" />
                                      </div>
                           
                                    <div class="form-group"> 
                                    <label>Company :</label>
                                      <select class="form-control" name="company" selected="selected" required>
                                      <option value="">Select Options</option>       
        
                                  <?php  if(!empty($customer)){
                          foreach ($customer as $c){ ?>        
                                        <option value="<?php  echo  $c["id"];?>"   >
                                        <?php  echo  $c["name"];?>
                                        </option>               
                                        <?php }} ?>
                                      </select> 
                                      </div>
                           
                        <div class="form-group">    
                      <label>Contractor :</label>
                      <select class="form-control" name="contractor_id" selected="selected" required>          
                     <option value="">Select Options</option>       
      <?php  if(!empty($contractor)){
                          foreach ($contractor as $con){   ?>       
                          <option value="<?php  echo  $con["id"];?>"   >
                          <?php  echo  $con["name"];?>
                          </option>               
                          <?php }} ?>
                      </select> 
                      </div>


                  </div>
                  <!-- panel-body -->
                </div>
                <!-- panel panel-default -->
              </div>
              <!-- col-lg-6 -->

              
              <div class="col-lg-6">
                <div class="panel panel-default">
                  <div class="panel-heading">Drivers & Helpers  Information </div>
                  <div class="panel-body">
                               <div class="form-group"> 
                                  <label>Driver:</label>
                                    <select class="form-control langOpt" multiple  name="driver_id[]" required>
                                   
                                     <?php  if(!empty($driverinformation)){
                                     foreach ($driverinformation as $d){    ?>   
  
                                    <option value="  <?php  echo $d["id"];?>"  >  
                                    <?php  echo  $d["name"]; ?>
                                    </option>               
                                    <?php }} ?>
                                    </select> 
                                </div>
                              <div class="form-group"> 
                                  <label>Helper:</label>
                                    <select class="form-control langOpt" multiple name="helper_id[]" required>
                                     <?php   if(!empty($helperinformation)){
                                      foreach ($helperinformation as $h){  ?>      
                                        <option value="  <?php  echo  $h["id"];?>"  >
                                      <?php  echo  $h["name"];?>
                                        </option>               
                                        <?php }} ?>
                                    </select> 
                               </div>
                  </div>
                  <!-- panel-body -->
                </div>
                <!-- panel panel-default -->
              </div>
              <!-- col-lg-6 -->
            </div>
            <!-- row -->

                        <input class="btn btn-primary" type="submit" name="register" value="submit" />


            </form>
        

        </div>
        <!-- box-body -->
      </div>
      <!-- box -->
</section>




<script>

function ValidateNumberOnly()
{
if ((event.keyCode < 45 || event.keyCode > 57)) 
{
   event.returnValue = false;
}
}

</script>



<script type="text/javascript">
$(document).ready(function() {
    $('#myform')
        .bootstrapValidator({
            feedbackIcons: {
                valid: 'glyphicon glyphicon-ok',
                invalid: 'glyphicon glyphicon-remove',
                validating: 'glyphicon glyphicon-refresh'
            },
            fields: {
                trip_type: {
                   trigger:'change keyup blur',
                    validators: {
                        notEmpty: {
                            message: 'The Trip type field  is required and cannot be empty'
                        }
                    }
                },
                vehicle_id: {
                   trigger:'change keyup blur',
                    validators: {
                        notEmpty: {
                            message: 'The vehicle field is required and cannot be empty'
                        }
                    }
                },
                    trip_category: {
                   trigger:'change keyup blur',
                    validators: {
                        notEmpty: {
                            message: 'The Trip category field is required and cannot be empty'
                        }
                    }
                },

                     date: {
                   trigger:'change keyup blur',
                    validators: {
                        notEmpty: {
                            message: 'The Trip category field is required and cannot be empty'
                        }
                    }
                },
                  description: {
                   trigger:'change keyup blur',
                    validators: {
                        notEmpty: {
                            message: 'The Remarks field is required and cannot be empty'
                        }
                    }
                },
                fuel: {
                   trigger:'change keyup change keyup blur',
                    validators: {
                        notEmpty: {
                            message: 'The fuel field  is required and cannot be empty'
                        }
                    }
                },
              start_meter_reading: {
                   trigger:'change keyup change keyup blur',
                    validators: {
                        notEmpty: {
                            message: 'The Meter Reading field  is required and cannot be empty'
                        }
                    }
                },
               product_type: {
                   trigger:'change keyup change keyup blur',
                    validators: {
                        notEmpty: {
                            message: 'The Route field  is required and cannot be empty'
                        }
                    }
                },

        product_id: {
                   trigger:'change keyup change keyup blur',
                    validators: {
                        notEmpty: {
                            message: 'The Product field  is required and cannot be empty'
                        }
                    }
                },

               product_quantity: {
                   trigger:'change keyup change keyup blur',
                    validators: {
                        notEmpty: {
                            message: 'The Product quantity field is required and cannot be empty'
                        }
                    }
                },
              product_temperature: {
                   trigger:'change keyup blur',
                    validators: {
                        notEmpty: {
                            message: 'The Product Temperature field is required and cannot be empty'
                        }
                    }
                },
              product_gravity: {
                   trigger:'change keyup blur',
                    validators: {
                        notEmpty: {
                            message: 'The Product gravity field  is required and cannot be empty'
                        }
                    }
                },
              company: {
                   trigger:'change keyup blur',
                    validators: {
                        notEmpty: {
                            message: 'The Company field is required and cannot be empty'
                        }
                    }
                },
             contractor_id: {
                   trigger:'change keyup blur',
                    validators: {
                        notEmpty: {
                            message: 'The Contractor field is required and cannot be empty'
                        }
                    }
                },

             'driver_id[]': {
                   trigger:'change keyup blur',
                    validators: {
                        notEmpty: {
                            message: 'The Driver field is required and cannot be empty'
                        }
                    }
                },

            'helper_id[]': {
                   trigger:'change keyup blur',
                    validators: {
                        notEmpty: {
                            message: 'The Helper field is required and cannot be empty'
                        }
                    }
                },


            }
        });
});


</script>

